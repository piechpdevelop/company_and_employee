<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    protected $redirectTo = '/companies';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $data=$this->validateLogin($request);
        $retdata=$this->attemptLogin($request);
         // dd($retdata);
        $password=bcrypt($request->password);
        // dd( $password);
        if ($this->attemptLogin($request)) {
            // dd('hello');
            return redirect()->intended($this->redirectTo);

        }else{
            Session::flash('error', 'invalid credentials!'); 

            return redirect()->back();
        }
        // return $this->sendFailedLoginResponse($request);


        // $userdata=User::where('email', $request->email)->where('password', $request->password)->first();
        // if( $userdata){

        // }else{
        //             return redirect('/login');

        // }

    }
    
    public function logout(Request $request)
    {
        $this->guard()->logout();

        $request->session()->invalidate();

        return redirect('/login');
    }

}