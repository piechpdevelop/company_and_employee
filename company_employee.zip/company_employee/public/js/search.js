// $(document).ready(function() {
//     var searchInput = $('#search-input');
//     var searchResults = $('#search-results');

//     searchInput.keyup(function() {
//         var query = searchInput.val();

//         $.ajax({
//             url: '/companies/search',
//             data: {
//                 search: query
//             },
//             success: function(data) {
//                 searchResults.html(data);
//             },
//             error: function(xhr, status, error) {
//                 console.log(error);
//             }
//         });
//     });
// });
