<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\CompanyController;

use App\Http\Controllers\EmployeeController;

Route::get('/login', [LoginController::class,'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class,'login'])->name('login');

Route::post('/logout', [LoginController::class,'logout'])->name('logout');


//company

Route::get('/companies', [CompanyController::class,'index'])->name('companies.index');

Route::get('/companies/create', [CompanyController::class,'create'])->name('companies.create');


Route::post('/companies', [CompanyController::class,'store'])->name('companies.store');


Route::get('/companies/{company}', [CompanyController::class,'show'])->name('companies.show');

Route::get('/companies/{company}/edit', [CompanyController::class,'edit'])->name('companies.edit');
Route::post('/companies/update', [CompanyController::class,'update'])->name('companies.update');

Route::get('/companies/{company}/destroy', [CompanyController::class,'destroy'])->name('companies.destroy');


Route::get('/companies/search', [CompanyController::class,'search'])->name('companies.search');



//employee

Route::get('/employees', [EmployeeController::class,'index'])->name('employees.index');

Route::get('/employees/create', [EmployeeController::class,'create'])->name('employees.create');

Route::post('/employees', [EmployeeController::class,'store'])->name('employees.store');

Route::get('/employees/{employee}', [EmployeeController::class,'show'])->name('employees.show');

Route::get('/employees/{employee}/edit', [EmployeeController::class,'edit'])->name('employees.edit');

Route::post('/employees/{employee}/update', [EmployeeController::class,'update'])->name('employees.update');

Route::get('/employees/{employee}/destroy', [EmployeeController::class,'destroy'])->name('employees.destroy');




//home
Route::get('/', function () {
    return view('welcome');
});

// Route::group(['namespace' => 'App\Http\Controllers'], function()
// {   
//     /**
//      * Home Routes
//      */
//     Route::get('/', 'HomeController@index')->name('home.index');

//     Route::group(['middleware' => ['guest']], function() {
//         /**
//          * Register Routes
//          */
//         Route::get('/register', 'RegisterController@show')->name('register.show');
//         Route::post('/register', 'RegisterController@register')->name('register.perform');

//         /**
//          * Login Routes
//          */
//         Route::get('/login', 'LoginController@show')->name('login.show');
//         Route::post('/login', 'LoginController@login')->name('login.perform');

//     });

//     Route::group(['middleware' => ['auth']], function() {
//         /**
//          * Logout Routes
//          */
//         Route::get('/logout', 'LogoutController@perform')->name('logout.perform');
//     });
// });



Route::get('/', function () {
    return view('welcome');
});