<?php $__env->startSection('content'); ?>
    <div class="container" style="background: white">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Edit Company')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('companies.update')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            
                             <input id="company_id" type="hidden" class="form-control" name="company_id" value="<?php echo e(old('id', $companies->id)); ?>">
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name', $companies->name)); ?>" required autocomplete="name" autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', $companies->email)); ?>" autocomplete="email">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="logo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Logo')); ?></label>

                                <div class="col-md-6">
                                    <?php if($companies->logo): ?>
                                        <img height="100px;" src="<?php echo e(asset('storage/logos/' . $companies->logo)); ?>" alt="<?php echo e($companies->name); ?>" style="max-width: 100%">
                                    <?php else: ?>
                                        <p>No logo uploaded yet.</p>
                                    <?php endif; ?>
                                    <input id="logo" type="file" class="form-control-file <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="logo">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="website" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Website')); ?></label>

                                <div class="col-md-6">
                                    <input id="website" type="url" class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="website" value="<?php echo e(old('website', $companies->website)); ?>" autocomplete="website">
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-sm btn-primary">
                                        <?php echo e(__('Update')); ?>

                                    </button>
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('companies.show', $companies->id)); ?>" class="btn btn-secondary">
                                        <?php echo e(__('Cancel')); ?>

                                    </a>
                                </div>
                            </div>   
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-and-registration\resources\views/companies/edit.blade.php ENDPATH**/ ?>