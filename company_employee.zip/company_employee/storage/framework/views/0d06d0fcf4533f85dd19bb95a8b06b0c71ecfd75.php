<?php $__env->startSection('content'); ?>
<style>
    .mb-3{
        margin: 25px;
    }
</style>
    <div class="container" style="background: white">
        <div class="mb-3">
            <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success">Add Employee</a>
          </div>
          <div align ="right" >
            <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-danger">Go to companies</a>
          </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><b>Employees List</b></div>
                    <br>
                    <div class="card-body">
                        <table class="table" border="3">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Company</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr>
                                        <td><?php echo e($employee->first_name); ?></td>
                                        <td><?php echo e($employee->last_name); ?></td>
                                        <td><?php echo e(!empty($employee->companies) ? $employee->companies->name : ''); ?></td>
                                        <td><?php echo e($employee->email); ?></td>
                                        <td><?php echo e($employee->phone); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('employees.show', $employee->id)); ?>" class="btn btn-primary btn-sm">View</a>
                                            <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="<?php echo e(route('employees.destroy', $employee->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($employees->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-and-registration\resources\views/employees/index.blade.php ENDPATH**/ ?>