<?php $__env->startSection('content'); ?>
<style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: auto;
        margin: 100px;
        font-size: medium;
    }

    .form-group {
        margin-bottom: 20px;
    }

</style>

<div class="container mt-5" style="background: white">
  <div class="card card-primary" >
    <div class="card-header" >
      <center><h3> Admin Login </h3></center>
    </div>
    <hr style="border: 1px solid black;" id="my-hr" width="55%" class="my-class" aria-label="Horizontal line across the page">
<form method="POST" action="<?php echo e(route('login')); ?>" class="navbar-form navbar-right">
   <?php echo e(csrf_field()); ?>

    <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                      <?php echo e(session('success')); ?>

                                    </div> 
                                <?php elseif(session('error')): ?>
                                    <div class="alert alert-danger">
                                      <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
    <div class="col-md-12 col-lg-4">
    <div class="form-group">
        <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
    </div>

    <div class="form-group">
        <label for="password"><?php echo e(__('Password')); ?></label>
        <input id="password" type="password" class="form-control" name="password" required>
    </div>
    <br><br>
    <div class="form-group">
        <button type="submit" class="btn btn-success">
            <?php echo e(__('Login')); ?>

        </button>
    </div>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-and-registration\resources\views/auth/login.blade.php ENDPATH**/ ?>