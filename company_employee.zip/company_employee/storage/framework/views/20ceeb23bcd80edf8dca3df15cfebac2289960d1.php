<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="background: white">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                  <div class="card-header">Company Name: <?php echo e($companies->name); ?></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo e(asset('logos/'.$companies->logo)); ?>" alt="<?php echo e($companies->name); ?> Logo" style="max-width: 100%">
                            </div>
                            <div class="col-md-6">
                                <p><strong>Email:</strong> <?php echo e($companies->email); ?></p>
                                <p><strong>Website:</strong> <a href="<?php echo e($companies->website); ?>" target="_blank"><?php echo e($companies->website); ?></a></p>
                                <a href="<?php echo e(route('companies.edit', $companies->id)); ?>" class="btn btn-success">Edit</a>
                                <a href="<?php echo e(route('companies.destroy', $companies->id)); ?>" class="btn btn-danger">Delete</a>
                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-primary">Back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-and-registration\resources\views/companies/show.blade.php ENDPATH**/ ?>