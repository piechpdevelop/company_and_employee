<?php $__env->startSection('content'); ?>
<style>
    .mb-3{
        margin: 25px;

    }
</style>
<div class="container" style="background: white">
    <div class="mb-3">
        <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary">Add company </a>
      
      
        <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-primary">Employees </a>
  <div align ="right"> <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>
                    </form>
                </div>
      </div>


      
    <div class="row justify-content-center" >
        <div class="col-md-12">
            <div class="card" >
                <div class="card-header"><b>Companies</b></div>
                <div class="card-body">
                    <table class="table" border="3">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Logo</th>
                                <th>Website</th>
                                <th>Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($company->name); ?></td>
                                <td><?php echo e($company->email); ?></td>
                                <td><img src="<?php echo e(asset('storage/logos/'.$company->logo)); ?>" width="50" height="50" alt="<?php echo e($company->name); ?> "></td>
                                <td><?php echo e($company->website); ?></td>
                                <td>
                                    <a href="<?php echo e(route('companies.show', $company->id)); ?>" class="btn btn-primary">view</a>
                                    <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-success">Edit</a>
                                    <a href="<?php echo e(route('companies.destroy', $company->id)); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($companies->links()); ?>

                </div>
                <div class="card-footer text-right">

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-and-registration\resources\views/companies/index.blade.php ENDPATH**/ ?>